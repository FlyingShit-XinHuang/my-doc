## 高可用ES编排

* ES集群包含Master、Data和Client三种角色Node，其中Master负责索引、分片、副本和Node的管理，Data负责保存数据，Client负责对外提供服务。
* 三者分别对应es-master-ds.json、es-data-ds.json和es-client-rc.json，其中Master和Data使用了DaemonSet来管理，Client使用了RC。
* 为限制DaemonSet创建的Pod数量，Master和Data的编排配置均使用了nodeSelector，标签分别为"kube-system/es-master-node":"true"和"kube-system/es-data-node":"true"。
* Master和Data Node扩容时添加含有对应标签的Node即可，Client扩容时只需使用kubectl scale命令。
* Master扩容时须额外注意MIN_MASTERS环境变量，建议Master数量为奇数个，MIN_MASTERS设置为floor(Master数量/2) + 1。通常有3个Master，MIN_MASTERS设置为2即可。
* TODO：未来使用k8s PetSet来管理Master和Node更为方便。